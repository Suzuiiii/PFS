import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class MCQ {                                                                                    // to declares a member's access in public
    public static void main(String[] args) throws FileNotFoundException {
        System.out.println ("*---------------------------------*");
        System.out.println ("❗                               ❗");
        System.out.println ("❗            WELCOME            ❗");
        System.out.println ("❗              TO               ❗");
        System.out.println ("❗              MCQ              ❗");
        System.out.println ("❗             Test              ❗");
        System.out.println ("❗                               ❗");
        System.out.println ("*---------------------------------*");
        System.out.println("Enter your Full Name: ");
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        int score=0;
        int wrong=0;
        System.out.println("*------------------------------------------------------------*");
        System.out.println("❗                                                            ❗");
        System.out.println("❗ Choose your Multiple Choice Question Set. The Options are: ❗");
        System.out.println("❗                                                            ❗");
        System.out.println("❗                    1. Java Basics                          ❗");
        System.out.println("❗                    2. HTML Basics                          ❗");
        System.out.println("❗                    3. CSS Basics                           ❗");
        System.out.println("❗          Choose a number to proceed on the Quiz            ❗");
        System.out.println("❗                                                            ❗");
        System.out.println("*------------------------------------------------------------*");
        int choice = sc.nextInt();
        if (choice == 1) {
            System.out.println("❗---Java basics questions---❗");
            System.out.println("Choose the correct letter\uD83D\uDE0A");
            File f = new File("MCQ1.csv");
            Scanner q1 = new Scanner(f);                                                            // to read the CSV Files
            while (q1.hasNextLine()) {
                String line = q1.nextLine();
                String line_array[] = new String[6];
                line_array = line.split(",");
                System.out.println("❗--------------------------------------------------------------❗");
                System.out.println(line_array[0]);
                System.out.println(line_array[1]);                                                  //answer choices
                System.out.println("A.)" + line_array[2]);
                System.out.println("B.)" + line_array[3]);
                System.out.println("C.)" + line_array[4]);
                System.out.println("D.)" + line_array[5]);
                System.out.println("❗--------------------------------------------------------------❗");
                System.out.println();
                System.out.println();
                Scanner ques = new Scanner(System.in);
                System.out.print("❗---Enter your Answer---❗: ");
                System.out.println();
                String correctAnswer = ques.nextLine();

                if (correctAnswer.equalsIgnoreCase(line_array[6])) {
                    System.out.println("✔---Your Answer is Correct\uD83D\uDE0A---✔");
                score++;
                } else {
                    System.out.println("❌--Incorrect\uD83E\uDD7A " + "The correct Answer is: " + line_array[6] +"--❌");
                wrong++;
                }

            }
        } else if (choice == 2) {
            System.out.println("❗---HTML basics questions---❗");
            System.out.println("Choose the correct letter\uD83D\uDE0A");
            File g = new File("MCQ2.csv");
            Scanner q1 = new Scanner(g);
            while (q1.hasNextLine()) {
                String line = q1.nextLine();
                String line_array[] = new String[6];
                line_array = line.split(",");
                System.out.println(line_array[0]);
                System.out.println(line_array[1]);
                System.out.println("A.)" + line_array[2]);
                System.out.println("B.)" + line_array[3]);
                System.out.println("C.)" + line_array[4]);
                System.out.println("D.)" + line_array[5]);
                System.out.println();
                Scanner ques = new Scanner(System.in);
                System.out.print("❗---Enter your Answer---❗: ");
                String correctAnswer = ques.nextLine();

                if (correctAnswer.equalsIgnoreCase(line_array[6])) {
                    System.out.println("✔---Your Answer is Correct\uD83D\uDE0A---✔");
                score++;
                } else {
                    System.out.println("❌--Incorrect\uD83E\uDD7A " + "The correct Answer is: " + line_array[6] +"--❌");
                wrong++;
                }

            }
        } else if (choice == 3) {

            System.out.println("❗---CSS basics questions---❗");
            System.out.println("Choose the correct letter\uD83D\uDE0A");
            File h = new File("MCQ3.csv");
            Scanner v1 = new Scanner(h);
            while (v1.hasNextLine()) {
                String line = v1.nextLine();
                String line_array[] = new String[6];
                line_array = line.split(",");
                System.out.println(line_array[0]);
                System.out.println(line_array[1]);
                System.out.println("A.)" + line_array[2]);
                System.out.println("B.)" + line_array[3]);
                System.out.println("C.)" + line_array[4]);
                System.out.println("D.)" + line_array[5]);
                System.out.println();
                Scanner ques = new Scanner(System.in);
                System.out.print("❗---Enter your Answer---❗: ");
                String correctAnswer = ques.nextLine();

                if (correctAnswer.equalsIgnoreCase(line_array[6])) {
                    System.out.println("✔--- Your Answer is Correct\uD83D\uDE0A ---✔");
                score++;
                } else {
                    System.out.println("❌---Incorrect\uD83E\uDD7A " + "The correct Answer is: " + line_array[6] +"---❌");
                wrong++;
                }
            }
        }
                    System.out.println("*--------------------------------------*");
                    System.out.println("❗                                      ❗");
                    if (score >=8 && score <=10){
                        System.out.println("      Congratulations You Passed!");
                    }else {
                        System.out.println("       Sorry You Failed\n       Oww no!! Please Try Again!! ");
                    }
                    System.out.println("❗                                      ❗");
                    System.out.println("*--------------------------------------*");
                    System.out.println("*--------------------------------------------------*");
                    System.out.println("❗                                                  ❗");
                    System.out.println("    Hello "+ name+" Your score is "+(score)+"/10");
                    System.out.println("    Your average is " +(score *10)+"%");
                    System.out.println("❗                                                  ❗");
                    System.out.println("*--------------------------------------------------*");
                    System.out.println("*--------------------------------*");
                    System.out.println("❗                                ❗");
                    System.out.println("    Your incorrect answer is "+ wrong );
                    System.out.println("❗                                ❗");
                    System.out.println("*--------------------------------*");
    }
}




